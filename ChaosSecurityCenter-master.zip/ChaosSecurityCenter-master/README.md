# ChaosSecurityCenter
仿支付宝手势密码，自定义手势密码View  

![Alt text](https://github.com/ChaosOctopus/ChaosSecurityCenter/blob/master/app/src/main/res/mipmap-xhdpi/for_one.png)  

![Alt2 text](https://github.com/ChaosOctopus/ChaosSecurityCenter/blob/master/app/src/main/res/mipmap-xhdpi/for_two.png)  

![Alt3 text](https://github.com/ChaosOctopus/ChaosSecurityCenter/blob/master/app/src/main/res/mipmap-xhdpi/for_three.png)  

[简书文章介绍](http://www.jianshu.com/p/ab8a3dbb6982)

