package com.chaos.chaossecuritycenter;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by yc.Zhao on 2017/11/30 0030.
 */
@GlideModule
public class BaseGlideModel extends AppGlideModule {
}
